import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from appium.webdriver.common.appiumby import AppiumBy
from appium.options.android import UiAutomator2Options
from Maccabi_app.login import Login
from Maccabi_app.bubbles import Bubbles
from Maccabi_app.commitment_screen import Commitment_screen
from Maccabi_app.timeline_commitment import Timeline_commitment
from appium.webdriver.common.mobileby import MobileBy as AppiumBy
from appium.webdriver.common.touch_action import TouchAction
import logging
from appium import webdriver
import unittest

class Tests(unittest.TestCase):
    def setUp(self):
        logging.basicConfig(level=logging.DEBUG)
        options = UiAutomator2Options().load_capabilities({
            'deviceName': 'R38N3014ZMX',
            'platformName': 'Android',
            'platformVersion': '11',
            'app': 'C:/applications/maccabi.apk',
            'autoGrantPermissions': True,
            'unlockType': 'pin',
            'unlockKey': '1111'
        })
        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', options=options)
        self.driver.implicitly_wait(30)
        self.login = Login(self.driver)
        self.bubbles = Bubbles(self.driver)
        self.timeline_commitment = Timeline_commitment(self.driver)
        self.commitment_screen = Commitment_screen(self.driver)

    def tearDown(self):
        self.driver.quit()

    def test_commitment(self):
        self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/dynamicActionButton").click()
        self.bubbles.ivExpand().click()
        self.bubbles.bubble_commitment().click()
        self.login.btn_transition_otp().click()
        self.login.tab_enter_with_password().click()
        self.login.entering_member_id().click()
        self.login.entering_member_id().send_keys("4242")
        self.driver.back()
        self.login.entering_password().click()
        self.login.entering_password().send_keys("Aa123456")
        self.driver.back()
        self.login.btn_enter().click()
        # Push notification
        wait = WebDriverWait(self.driver, 60)
        this_my_gadget = wait.until(EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnAction2")))
        this_my_gadget.click()
        # Approving phone number
        this_my_number = wait.until(EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnConfirm")))
        this_my_number.click()
        # Checking that new commitment was created
        # Get the current date
        today = datetime.date.today()

        # Format the date and print it in DD-MM-YY format
        formatted_date = today.strftime("%d/%m/%y")

        # locate the view group element using an appropriate selector
        view_group = self.driver.find_element(By.XPATH,
                                              "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/androidx.drawerlayout.widget.DrawerLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.ScrollView/android.widget.FrameLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[1]")
        # sleep(5)
        # find all the TextView elements within the view group using a loop
        text_views = []
        sleep(5)
        for element in view_group.find_elements(By.CLASS_NAME, "android.widget.TextView"):
            text_views.append(element)
        # print the text of each TextView element
        text_views_texts = []
        for text_view in text_views:
            text_views_texts.append(text_view.text)
        print(text_views_texts)
        self.assertTrue(text_views_texts[0] == formatted_date)
        #self.assertTrue(text_views_texts[1] == "טסט 53")
        self.assertTrue(text_views_texts[2] == "חדש")
        self.assertTrue(text_views_texts[3] == "בקשות להתחייבות")
        # for text in text_views_texts:
        # print(text)


    def test_family_picker(self):
        self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/dynamicActionButton").click()
        self.bubbles.ivExpand().click()
        self.bubbles.bubble_commitment().click()
        self.login.btn_transition_otp().click()
        self.login.tab_enter_with_password().click()
        self.login.entering_member_id().click()
        self.login.entering_member_id().send_keys("4242")
        self.driver.back()
        self.login.entering_password().click()
        self.login.entering_password().send_keys("Aa123456")
        self.driver.back()
        self.login.btn_enter().click()
        # Push notification
        wait = WebDriverWait(self.driver, 60)
        this_my_gadget = wait.until(
            EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnAction2")))
        this_my_gadget.click()
        # Approving phone number
        this_my_number = wait.until(
            EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnConfirm")))
        this_my_number.click()
        # Click on first commitment
        timeline_items_list = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/timeline_items_list")
        first_commitment = timeline_items_list.find_element(AppiumBy.CLASS_NAME, "android.view.ViewGroup")
        first_commitment.click()
        sleep(10)
        self.timeline_commitment.btn_fab().click()
        # בקשה חדשה להתחייבות
        timeline_fab_list = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/timeline_fab")
        buttons_fab=[]
        for button in timeline_fab_list.find_elements(AppiumBy.CLASS_NAME, "android.widget.ImageButton"):
            buttons_fab.append(button)
        buttons_fab[0].click()
        # Family picker
        list_of_members = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/familyMemberPicker")
        members = []
        for member in list_of_members.find_elements(AppiumBy.CLASS_NAME, "android.widget.LinearLayout"):
            members.append(member)
        members[0].click()
        referral_selection = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/cmpReferralSelection")
        referral_slct_click = referral_selection.find_element(AppiumBy.CLASS_NAME, "android.widget.TextView")
        referral_slct_click.click()
        # אין לי הפניה
        rv_list = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/rvList")
        rv = []
        for i in rv_list.find_elements(AppiumBy.CLASS_NAME,"android.widget.TextView"):
            rv.append(i)
        rv[1].click()
        sleep(10)


if __name__ == '__main__':
    unittest.main()