import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from appium.webdriver.common.appiumby import AppiumBy
from appium.options.android import UiAutomator2Options
from Maccabi_app.login import Login
from Maccabi_app.bubbles import Bubbles
from Maccabi_app.commitment_screen import Commitment_screen
from Maccabi_app.timeline_commitment import Timeline_commitment
from appium.webdriver.common.mobileby import MobileBy as AppiumBy
from appium.webdriver.common.touch_action import TouchAction
import logging
from appium import webdriver
from appium.webdriver.appium_service import AppiumService
import unittest

class Tests(unittest.TestCase):
    def setUp(self):
        #logging.basicConfig(level=logging.DEBUG)
        self.appium_service = AppiumService()
        self.appium_service.start(args=['--address', "127.0.0.1", '--port', "4723", "--base-path", '/wd/hub'])
        options = UiAutomator2Options().load_capabilities({
            'deviceName': 'R38N3014ZMX',
            'platformName': 'Android',
            'platformVersion': '11',
            'app': 'C:/applications/maccabi.apk',
            'autoGrantPermissions': True,
            'unlockType': 'pin',
            'unlockKey': '1111'
        })
        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', options=options)
        self.driver.implicitly_wait(30)
        self.login = Login(self.driver)
        self.bubbles = Bubbles(self.driver)
        self.timeline_commitment = Timeline_commitment(self.driver)
        self.commitment_screen = Commitment_screen(self.driver)

    def tearDown(self):
        self.driver.remove_app('com.ideomobile.maccabi')
        self.driver.quit()
        self.appium_service.stop()

    def test_commitment(self):
        """ A test that passes authorization, creates a new one commitment and checks that the new commitment was created correctly """
        # The LogIn process
        self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/dynamicActionButton").click()
        self.bubbles.ivExpand().click()
        self.bubbles.bubble_commitment().click()
        self.login.btn_transition_otp().click()
        self.login.tab_enter_with_password().click()
        self.login.entering_member_id().click()
        self.login.entering_member_id().send_keys("125")
        self.driver.back()
        self.login.entering_password().click()
        self.login.entering_password().send_keys("Aa123456")
        self.driver.back()
        self.login.btn_enter().click()
        # Push notification
        wait = WebDriverWait(self.driver, 60)
        this_my_gadget = wait.until(EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnAction2")))
        this_my_gadget.click()
        # Approving phone number
        this_my_number = wait.until(EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/btnConfirm")))
        this_my_number.click()
        # Continuing of creating new commitment
        self.timeline_commitment.btn_fab().click()
        self.timeline_commitment.new_commitment().click()
        # Pick on the parent family member
        list_of_members = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/familyMemberPicker")
        members = []
        for member in list_of_members.find_elements(AppiumBy.CLASS_NAME, "android.widget.LinearLayout"):
            members.append(member)
        members[0].click()
        self.commitment_screen.choice_reference().click()
        self.commitment_screen.i_have_no_reference().click()
        # Scrolling down
        element = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/ivIcon")
        x = element.location['x']
        y = element.location['y']
        # Creating object  TouchAction
        action = TouchAction(self.driver)
        # Scrolling down
        action.long_press(x=x, y=y).move_to(x=x, y=y - 250).release().perform()
        # Entering of medical field
        self.commitment_screen.medical_field().click()
        self.commitment_screen.entering_medical_field().click()
        self.commitment_screen.entering_medical_field().send_keys("עיניים")
        self.driver.back()
        self.commitment_screen.eyes_medical_field().click()
        self.commitment_screen.btn_continue().click()
        # Transition to second screen of commitment
        self.commitment_screen.btn_not_appointment().click()
        self.commitment_screen.btn_approve().click()
        # Transition to third screen of commitment
        # Attaching files
        self.commitment_screen.add_file().click()
        self.commitment_screen.icon_camera().click()
        # Make a photo
        camera_instructions = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/action_dismiss_camera_user_instructions")
        camera_instructions.click()
        camera_shot = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/button_camera_shot")
        camera_shot.click()
        cancel_btn = wait.until(EC.visibility_of_element_located((AppiumBy.ACCESSIBILITY_ID, "ביטול")))
        camera_confirm = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/camera_confirm_ic")
        camera_confirm.click()
        camera_confirm.click()
        ibDelete = wait.until(EC.visibility_of_element_located((AppiumBy.ID, "com.ideomobile.maccabi:id/ibDelete")))
        self.commitment_screen.send_request().click()
        # PopUp your request was sent successfully
        pop_up_success = self.driver.find_element(AppiumBy.ID, "android:id/content")
        # Test that check the PopUp of success was displayed
        self.assertTrue(pop_up_success.is_displayed())
        # OK button
        ok_btn = self.driver.find_element(AppiumBy.ID, "com.ideomobile.maccabi:id/btn_negative")
        ok_btn.click()
        # Checking that new commitment was created
        # Find all the TextView elements in a commitment that was created within the view group using a loop
        text_views = []
        for element in self.timeline_commitment.first_created_commitment().find_elements(AppiumBy.CLASS_NAME, "android.widget.TextView"):
            text_views.append(element)
        # Print the text of each TextView element
        text_views_texts = []
        for text_view in text_views:
            text_views_texts.append(text_view.text)
        print(text_views_texts)
        # Get the current date
        today = datetime.date.today()
        # Format the date in format of application
        formatted_date = today.strftime("%d/%m/%y")
        # The test that check that the date who appeared in new commitment is correct
        self.assertTrue(text_views_texts[0] == formatted_date)
        # The test that check that new commitment was created for correcting family member
        self.assertTrue(text_views_texts[1] == "תם")
        # The test that check that the status of created commitment is correct
        self.assertTrue(text_views_texts[2] == "חדש")
        # The test that check the name of created commitment is correct
        self.assertTrue(text_views_texts[3] == "בקשות להתחייבות")

if __name__ == '__main__':
    unittest.main()



